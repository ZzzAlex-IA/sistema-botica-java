
package Main;

import Views.SystemView;



public class Main {
     public static void main(String[] args) {
            SystemView login = new SystemView();
            login.setVisible(true);                   
        } 
}
